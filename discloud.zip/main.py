import discord
import yt_dlp
import asyncio
import os
import requests, re, urllib.parse, traceback
from discord.ext import commands

intents = discord.Intents.all()
intents.message_content = True
bot = commands.Bot(command_prefix="-", intents=intents)

ytdl = yt_dlp.YoutubeDL({
    'format': 'bestaudio[ext=opus]/bestaudio/best',
    'noplaylist': True,
    'quiet': True,
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'source_address': '0.0.0.0',
    'extractor_args': {'youtube': {'player_client': ['android_music','android','mweb'], 'player_skip': ['webpage']}}
})
ffmpeg_options = {'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5', 'options': '-vn'}

queue_list = []

class Buttons(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    @discord.ui.button(label="⏭️ تخطي", style=discord.ButtonStyle.primary)
    async def skip(self, interaction, button):
        vc = interaction.guild.voice_client
        if vc and vc.is_playing(): vc.stop()
        await interaction.response.defer()
    @discord.ui.button(label="⏹️ ايقاف", style=discord.ButtonStyle.danger)
    async def stop(self, interaction, button):
        queue_list.clear()
        vc = interaction.guild.voice_client
        if vc and vc.is_playing(): vc.stop()
        await interaction.response.defer()

async def play_next(guild):
    if queue_list:
        url, title, channel = queue_list.pop(0)
        vc = guild.voice_client
        if not vc: return
        source = discord.FFmpegPCMAudio(url, **ffmpeg_options)
        vc.play(source, after=lambda e: asyncio.run_coroutine_threadsafe(play_next(guild), bot.loop))
        embed = discord.Embed(description=f"**🎶 الان يعمل:\n{title}**", color=0x9b59b6)
        await channel.send(embed=embed, view=Buttons())

@bot.event
async def on_ready():
    print(f"✅ جاهز: {bot.user}")

@bot.event
async def on_message(message):
    if message.author.bot: return
    content = message.content.strip()
    if not content: return

    if content.startswith("ش "):
        song = content[2:].strip()
        if not message.author.voice:
            await message.channel.send("ادخل روم صوتي اولاً")
            return
        if not message.guild.voice_client:
            await message.author.voice.channel.connect(self_deaf=True, self_mute=False)
        elif message.guild.voice_client.channel!= message.author.voice.channel:
            await message.guild.voice_client.move_to(message.author.voice.channel)

        await message.channel.send(f"🔍 جاري البحث يبوي\n**{song}**")
        try:
            video_id = None
            if song.startswith("http"):
                m = re.search(r"(?:v=|be/|shorts/)([A-Za-z0-9_-]{11})", song)
                video_id = m.group(1) if m else None
                video_url = song
            else:
                q = urllib.parse.quote(song)
                html = requests.get(f"https://www.youtube.com/results?search_query={q}", headers={"User-Agent":"Mozilla/5.0"}, timeout=15).text
                ids = re.findall(r'"videoId":"([^"]+)"', html)
                if not ids:
                    raise Exception("youtube search رجع فاضي")
                video_id = ids[0]
                video_url = f"https://www.youtube.com/watch?v={video_id}"

            audio_url = None
            title = song
            # نجرب 5 سيرفرات بديلة
            apis = [
                f"https://pipedapi.adminforge.de/streams/{video_id}",
                f"https://pipedapi.kavin.rocks/streams/{video_id}",
                f"https://api.piped.privacydev.net/streams/{video_id}",
                f"https://inv.nadeko.net/api/v1/videos/{video_id}",
                f"https://invidious.nerdvpn.de/api/v1/videos/{video_id}"
            ]
            found = False
            for api_url in apis:
                try:
                    print(f"نجرب: {api_url}")
                    r = requests.get(api_url, timeout=15, headers={"User-Agent":"Mozilla/5.0"}).json()
                    # Piped format
                    if 'audioStreams' in r and r['audioStreams']:
                        best = sorted(r['audioStreams'], key=lambda x: x.get('bitrate',0), reverse=True)[0]
                        audio_url = best['url']
                        title = r.get('title', song)
                        found = True
                        break
                    # Invidious format
                    if 'adaptiveFormats' in r:
                        audios = [f for f in r['adaptiveFormats'] if 'audio' in f.get('type','')]
                        if audios:
                            best = sorted(audios, key=lambda x: int(x.get('bitrate',0)), reverse=True)[0]
                            audio_url = best['url']
                            title = r.get('title', song)
                            found = True
                            break
                except Exception as p_e:
                    print(f"فشل {api_url}: {p_e}")
                    continue
            if not found and not audio_url:
                raise Exception(f"كل السيرفرات محظورة - جرب نقل البوت من Replit")
            queue_list.append((audio_url, title, message.channel))
            vc = message.guild.voice_client
            if not vc.is_playing() and not vc.is_paused():
                await play_next(message.guild)
            else:
                await message.channel.send(f"**➕ تمت الاضافة:\n{title}**", view=Buttons())

        except Exception as e:
            traceback.print_exc()
            print(f"ERROR SEARCH: {e}")
            await message.channel.send(f"ما لقيت الاغنية\n`{e}`")

    if content == "س":
        vc = message.guild.voice_client
        if vc and vc.is_playing(): vc.stop(); await message.channel.send("⏭️ تخطي")
    if content == "ق":
        queue_list.clear()
        vc = message.guild.voice_client
        if vc and vc.is_playing(): vc.stop()
        await message.channel.send("⏹️ وقفنا بس باقي بالروم")
    if content == "ص":
        vc = message.guild.voice_client
        if vc and vc.is_playing(): vc.pause(); await message.channel.send("⏸️ وقف")
    if content == "ك":
        vc = message.guild.voice_client
        if vc and vc.is_paused(): vc.resume(); await message.channel.send("▶️ كملنا")

bot.run(os.getenv("TOKEN"))